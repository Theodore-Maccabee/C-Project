﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;


namespace PRG1782_PROJECT_MILESTONE_2
{
    enum Menu //Menu declaration.
    {
        CaptureDetails = 1,
        CheckTokenQualification,
        ShowStats,
        AveragePizzas,
        MinMaxAge,
        LoyaltyAward,
        Chance,
        Exit
    }

    class Applicant
    {
        // Declares the variables as a private but provides a public get/set method.
        public string Name { get; set; }
        public int Age { get; set; }
        public int HighScoreRank { get; set; }
        public DateTime StartingDate { get; set; }
        public int PizzasConsumed { get; set; }
        public int BowlingHighScore { get; set; }
        public bool IsEmployed { get; set; }
        public bool AreParentsEmployed { get; set; }
        public string SlushPuppyPreference { get; set; }
        public int SlushPuppiesConsumed { get; set; }
        public bool Added { get; set; }
        public int Credits {  get; set; }

        public Applicant(string name, int age, int highScoreRank, bool added, DateTime startingDate, int pizzasConsumed, int bowlingHighScore, bool isEmployed, bool areParentsEmployed, string slushPuppyPreference, int slushPuppiesConsumed)
        {
            // Sets all the variables.
            Name = name;
            Age = age;
            HighScoreRank = highScoreRank;
            StartingDate = startingDate;
            PizzasConsumed = pizzasConsumed;
            BowlingHighScore = bowlingHighScore;
            IsEmployed = isEmployed;
            AreParentsEmployed = areParentsEmployed;
            SlushPuppyPreference = slushPuppyPreference;
            SlushPuppiesConsumed = slushPuppiesConsumed;
            Added = added;
        }
    }

    class Program
    {
        static List<Applicant> applicants = new List<Applicant>();
        static List<Applicant> qualifiedApplicants = new List<Applicant>();
        static int deniedCount = 0;
        static bool qualificationsChecked = false; // Prevents multiple checks on the same applicant.
        public static bool Loading = false;

        static void Main(string[] args)
        {
            Console.ForegroundColor = ConsoleColor.Cyan; // Changes the colour of the console text. = Additional Feature
            Load();
            // Display qualification process details
            Console.WriteLine("The qualification process to determine loyal customers is rigorous and only for the elite.");
            Console.WriteLine("To qualify you need to:");
            Console.WriteLine("- Have parent/guardian that is employed, and be under 18.");
            Console.WriteLine("- Be a member for at least 2 years.");
            Console.WriteLine("- Have a highscore rank over 2000 or a Bowling Highscore over 1500 or combined average above 1200.");
            Console.WriteLine("- Have a monthly average of at least 3 pizzas consumed.");
            Console.WriteLine("- Have a monthly average of over 4 slushies.");
            Console.WriteLine("Remember, when you're a loyal customer you get special treatment ;)");
            Console.WriteLine("");

            bool running = true;

            while (running)
            {
                // Ask the user what they want to do next.
                // Asci art of the name. = Additional Feature

                Console.WriteLine(" ______     ______     ______   ______     ______     ______     __         __     ______     ______   \r\n/\\  == \\   /\\  ___\\   /\\__  _\\ /\\  == \\   /\\  __ \\   /\\  ___\\   /\\ \\       /\\ \\   /\\  ___\\   /\\  ___\\  \r\n\\ \\  __<   \\ \\  __\\   \\/_/\\ \\/ \\ \\  __<   \\ \\ \\/\\ \\  \\ \\___  \\  \\ \\ \\____  \\ \\ \\  \\ \\ \\____  \\ \\  __\\  \r\n \\ \\_\\ \\_\\  \\ \\_____\\    \\ \\_\\  \\ \\_\\ \\_\\  \\ \\_____\\  \\/\\_____\\  \\ \\_____\\  \\ \\_\\  \\ \\_____\\  \\ \\_____\\\r\n  \\/_/ /_/   \\/_____/     \\/_/   \\/_/ /_/   \\/_____/   \\/_____/   \\/_____/   \\/_/   \\/_____/   \\/_____/");
                Console.WriteLine("Choose an option:");
                Console.WriteLine("1. Capture Details");
                Console.WriteLine("2. Check game token credit qualification");
                Console.WriteLine("3. Show current arcade & bowling stats");
                Console.WriteLine("4. Average Pizza");
                Console.WriteLine("5. Display Min and Max Age");
                Console.WriteLine("6. Check Loyalty Award");
                Console.WriteLine("7. Guess a number.");
                Console.WriteLine("8. Exit");
                Menu choice = (Menu)int.Parse(Console.ReadLine());

                switch (choice) // The menu for the user to choose an option
                {
                    case Menu.CaptureDetails:
                        Load();
                        CaptureDetails();
                        break;
                    case Menu.CheckTokenQualification:
                        if (!qualificationsChecked)
                        {
                            Load();
                            CheckTokenQualification();
                            qualificationsChecked = true;
                        }
                        else
                        {
                            Load();
                            Console.Clear();
                            Console.WriteLine("Qualification has already been checked for all applicants."); // Prevents redundancy.
                        }
                        break;
                    case Menu.ShowStats:
                        Load();
                        ShowStats();
                        break;
                    case Menu.AveragePizzas:
                        Load();
                        AveragePizzas();
                        break;
                    case Menu.MinMaxAge:
                        Load();
                        MinMaxAge();
                        break;
                    case Menu.LoyaltyAward:
                        Load();
                        LoyaltyAward();
                        break;
                    case Menu.Chance:
                        Load();
                        Random(); //Additional feature random number generator, haven't been taught.
                        break;
                    case Menu.Exit:
                        running = false;
                        break;
                }
            }
        }

        static void CaptureDetails() // Collecting the applicants informantion.
        {
            Console.Clear();
            bool capturing = true;
            while (capturing)
            {
                Console.Write("Enter Name: ");
                string name = Console.ReadLine();

                Console.Write("Enter Age: ");
                int age = int.Parse(Console.ReadLine());

                Console.Write("Enter High Score Rank: ");
                int highScoreRank = int.Parse(Console.ReadLine());

                Console.Write("Enter Starting Date (yyyy-mm-dd): ");
                DateTime startingDate = DateTime.Parse(Console.ReadLine());

                Console.Write("Enter Number of Pizzas Consumed: ");
                int pizzasConsumed = int.Parse(Console.ReadLine());

                Console.Write("Enter Bowling High Score: ");
                int bowlingHighScore = int.Parse(Console.ReadLine());

                bool isEmployed = false;
                bool areParentsEmployed = false;

                if (age < 18)
                {
                    Console.Write("Are your parents employed (true/false): ");
                    areParentsEmployed = bool.Parse(Console.ReadLine());
                }
                else
                {
                    Console.Write("Are you employed (true/false): ");
                    isEmployed = bool.Parse(Console.ReadLine());
                }

                Console.Write("Enter Slush Puppy Flavour Preference: ");
                string slushPuppyPreference = Console.ReadLine();

                Console.Write("Enter Slush Puppies Consumed: ");
                int slushPuppiesConsumed = int.Parse(Console.ReadLine());

                bool added = false;
                // Adds the applicants info to a list. 
                applicants.Add(new Applicant(name, age, highScoreRank, added, startingDate, pizzasConsumed, bowlingHighScore, isEmployed, areParentsEmployed, slushPuppyPreference, slushPuppiesConsumed));

                Console.Write("Do you want to capture more applicants? (Y/N): "); //Allows the user to add multiple applicants.
                string response = Console.ReadLine().ToUpper();
                capturing = response == "Y";

                qualificationsChecked = false; // Reset the check flag when new details are captured
                Console.Clear();
            }
        }

        static void CheckTokenQualification()
        {
            Console.Clear();
            foreach (var applicant in applicants) // cycles through each added applicant to make sure everyone got verified.
            {
                bool qualifies = false;
                bool isAdded = applicant.Added;
                bool employedOrParentsEmployed = applicant.IsEmployed || applicant.AreParentsEmployed;
                bool loyalCustomer = (DateTime.Now - applicant.StartingDate).TotalDays >= 365 * 2;
                bool highScoresQualified = applicant.HighScoreRank > 2000 || applicant.BowlingHighScore > 1500 || ((applicant.HighScoreRank + applicant.BowlingHighScore) / 2.0) > 1200;
                bool pizzasQualified = applicant.PizzasConsumed / ((DateTime.Now - applicant.StartingDate).TotalDays / 30.0) >= 3;
                bool slushPuppyQualified = applicant.SlushPuppiesConsumed / ((DateTime.Now - applicant.StartingDate).TotalDays / 30.0) > 4;
                bool slushPuppyFlavourQualified = (applicant.SlushPuppyPreference != "Gooey Gulp Galore");
                if (employedOrParentsEmployed && loyalCustomer && highScoresQualified && pizzasQualified && slushPuppyQualified && slushPuppyFlavourQualified)
                {
                    qualifies = true;
                    if (isAdded == false)
                    {
                        qualifiedApplicants.Add(applicant);
                        Console.WriteLine($"{applicant.Name} is qualified.");
                        applicant.Added = true; // Adds a value to the applicant that will prevent multiple qualified applicants in the list.
                    }

                }
                else
                {
                    if (isAdded == false)
                    {
                        deniedCount++;
                        applicant.Added = true; // Adds a value to the applicant that will prevent multiple denied applicants in the list.
                    }
                    // Gives reasons for each of the following deniels 
                    Console.WriteLine($"{applicant.Name} is not qualified.");
                    if (!employedOrParentsEmployed)
                    {
                        if (applicant.Age < 18)
                        {
                            Console.WriteLine($"{applicant.Name}, Your parents need to be employeed.");
                        }
                        else
                        {
                            Console.WriteLine($"{applicant.Name}, You need to be employeed.");
                        }
                    }
                    if (!loyalCustomer)
                    {
                        Console.WriteLine($"{applicant.Name}, You need to be a customer for at least 2 years.");
                    }
                    if (!highScoresQualified)
                    {
                        Console.WriteLine($"{applicant.Name}, Needs to play more to achieve the required score.");
                    }
                    if (!pizzasQualified)
                    {
                        Console.WriteLine($"{applicant.Name}, Needs to eat more pizzas, at least 3 per month.");
                    }
                    if (!slushPuppyQualified)
                    {
                        Console.WriteLine($"{applicant.Name}, Needs to drink more slush puppies.");
                    }
                    if (!slushPuppyFlavourQualified)
                    {
                        Console.WriteLine($"{applicant.Name}, Your favourite drink can't be Gooey Gulp Galore.");
                    }
                }
            }

            Console.WriteLine("Token qualification check completed."); //Lets the user know that the process is complete.
        }

        static void ShowStats()
        {
            // Adds all the scores into a list and finds the Max and min number. = Additional feature
            Console.Clear();
            var arcadeHighScores = applicants.Select(a => a.HighScoreRank).ToList();
            var bowlingHighScores = applicants.Select(a => a.BowlingHighScore).ToList();

            int highestArcadeScore = arcadeHighScores.Max();
            int lowestArcadeScore = arcadeHighScores.Min();
            int highestBowlingScore = bowlingHighScores.Max();
            int lowestBowlingScore = bowlingHighScores.Min();
            // Displays the max and min Arcade stats. = Additional feature
            Console.WriteLine("Arcade Stats:");
            Console.WriteLine($"Highest Arcade Score: {highestArcadeScore}");
            Console.WriteLine($"Lowest Arcade Score: {lowestArcadeScore}");
            // Displays the max and min Bowling stats. = Additional feature
            Console.WriteLine("\nBowling Stats:");
            Console.WriteLine($"Highest Bowling Score: {highestBowlingScore}");
            Console.WriteLine($"Lowest Bowling Score: {lowestBowlingScore}");
            Console.WriteLine("");

            //Allows the user to see how many applicants have been qualified and denied.
            Console.WriteLine($"Total Applicants: {applicants.Count}");
            Console.WriteLine($"Qualified Applicants: {qualifiedApplicants.Count}");
            Console.WriteLine($"Denied Applicants: {deniedCount}");


        }

        static void AveragePizzas()
        {
            int totalPizzas = 0;
            float averagePizzasConsumed = 0;
            foreach (var applicant in applicants)
            {
                totalPizzas += applicant.PizzasConsumed;
                averagePizzasConsumed = totalPizzas / applicants.Count;
            }
            Console.WriteLine("The average amount of pizzas consumed is " + averagePizzasConsumed);
        }
        static void MinMaxAge()
        {
            int minAge = 999;
            int maxAge = 0;
            foreach (var applicant in applicants) // Sorts through the youngest and oldest applicant.
            {
                if (minAge > applicant.Age)
                {
                    minAge = applicant.Age; //minAge = The youngest applicant
                }

                if (maxAge < applicant.Age)
                {
                    maxAge = applicant.Age;//maxAge = The oldest applicant
                }

            }
            Console.WriteLine("Youngest applicant: " + minAge);
            Console.WriteLine("Oldest applicant: " + maxAge);

        }
        static void LoyaltyAward()
        {
            double LoyalTime;
            foreach (var applicant in applicants)
            {
                LoyalTime = (DateTime.Now - applicant.StartingDate).TotalDays; // Takes current time and minus the startingdate to get the total days the applicant has been loyal.
                if (LoyalTime >= 3650) // If the applicant has been a loyal customer for more than 3650 days (10 years)
                {
                    Console.WriteLine($"{applicant.Name} has been a loyal customer for 10+ years, you can now recieve an unlimited amount of credits");
                }
                else
                    Console.WriteLine($"{applicant.Name} has not been a loyal customer for 10+ years");
            }
        }

        static void Load()
        {
            Console.Clear();
            string ASpace = string.Empty;
            string LSpace = string.Empty;
            string CSpace = string.Empty;
            int TotalLength = 50; // The total length of the loading screen.
            do //The entire loading screen built with for loops.
            {
                LSpace = "";
                for (int j = 0; j < ((TotalLength / 2) - 7); j++)
                { LSpace += " "; }
                for (int i = 0; i < TotalLength; i++)
                {
                    for (int j = 0; j < 12; j++)
                    {
                        ASpace = "";
                        CSpace = "";
                        for (int l = 1; l <= i; l++)
                        { ASpace += "-"; }
                        for (int l = TotalLength - 2; l >= i; l--)
                        { CSpace += "-"; }
                        Console.WriteLine("|" + ASpace + "0" + CSpace + "|");
                        if (j == 5) { Console.WriteLine(LSpace + "...LOADING..."); }
                    }
                    Thread.Sleep(5); // How long the computer waits between loading intructions.
                    Console.Clear();
                }
            }
            while (Loading);
        }
        static void Random() //Additional feature, random number generator, haven't been taught.
        {
            // Random number generator game to win a prize
            Random rng = new Random();
            int guess;
            int rand1 = rng.Next(10); // Generates a random number between 0 and 9.
            Console.WriteLine("Pick a number between 0 and 9 ?");
            guess = int.Parse(Console.ReadLine());
            if( rand1 == guess) // Win condition. The users guesses the same number
            {
                Console.WriteLine("CONGRATS! You chose the right number ");
                Console.WriteLine("Go to the counter and choose one item in the small pile for free !");
                Console.WriteLine("");
            }
            else
            {
                Console.WriteLine($"Sorry, the number was {rand1}. Come back tomorrow.");
            }
        }


    }

}